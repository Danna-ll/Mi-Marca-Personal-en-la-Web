alert 
("Para probar los pseudocódigos, te invito a descargar Pseint. El botón de descarga está en la parte baja de este mensaje :). Gracias");